function validate() {
    var fname = document.reg_form.fname;
    var password = document.reg_form.password;
    var name = document.reg_form.name;

    if (fname.value.length <= 0) {
        alert("Id is required");
        fname.focus();
        return false;
    }
    if (password.value.length <= 0) {
        alert("Password is required");
        password.focus();
        return false;
    }
    if (name.value.length <= 0) {
        alert("Name is required");
        name.focus();
        return false;
    }
    var address = document.reg_form.address;
    var gender = document.reg_form.gender;
    if (address.value.length <= 0) {
        alert("Address is required");
        address.focus();
        return false;
    }
    if (gender.value.length <= 0) {
        alert("Gender is required");
        gender.focus();
        return false;
    }